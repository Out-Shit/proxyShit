<!DOCTYPE html>
  <html lang='en' dir='ltr'>
    <head>
      <meta charset='utf-8'>
       <meta http-equiv='refresh' content='5'>
      <title>LOG IS HERE</title>
    </head>
    <body>
      <pre>
  ["Shift","H","A","H","A","H","A","Enter"]
