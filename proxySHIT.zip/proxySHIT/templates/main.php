<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div id="container">
		<form action="index.php" method="post" style="margin-bottom:0;">
			<input name="url" type="hidden" style="width:400px;" autocomplete="off" value="https://damweb.ca" />
			<input type="submit" value="Go" />
		</form>
		<script type="text/javascript">
			document.getElementsByName("url")[0].focus();
		</script>
</div>
</body>
</html>
